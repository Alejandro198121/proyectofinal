package controller;

import view.RegistroAlmacenes;

public class AplMain {

	public static void main(String[] args) {

		Controller controler = new Controller();
		//new RegistroAlmacenes();
		
	}

}
